import { useState, useRef, useEffect } from "react";
import { ROOMS, BUILDINGS, Room } from "./data/campusData";
import { findRoute, RouteResult } from "./utils/routing";
import { CampusMap } from "./components/CampusMap";
import { IndoorMap } from "./components/IndoorMap";

const ALL_ROOMS = Object.values(ROOMS);

function RoomSearch({
  label,
  value,
  onChange,
  color,
  icon,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  color: string;
  icon: string;
}) {
  const [query, setQuery] = useState(value);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setQuery(value);
  }, [value]);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const filtered =
    query.length >= 1
      ? ALL_ROOMS.filter(
          (r) =>
            r.id.toLowerCase().includes(query.toLowerCase()) ||
            r.name.toLowerCase().includes(query.toLowerCase())
        ).slice(0, 8)
      : ALL_ROOMS.slice(0, 6);

  const selectedRoom = ROOMS[value];
  const building = selectedRoom ? BUILDINGS[selectedRoom.buildingId] : null;

  return (
    <div ref={ref} className="relative flex-1 min-w-0">
      <label
        className="block text-xs mb-1.5"
        style={{ color: color, fontWeight: 600 }}
      >
        {icon} {label}
      </label>
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
            if (ROOMS[e.target.value.toUpperCase()]) {
              onChange(e.target.value.toUpperCase());
            } else {
              onChange("");
            }
          }}
          onFocus={() => setOpen(true)}
          placeholder="z. B. A101 oder B205"
          className="w-full rounded-xl border-2 px-4 py-3 text-sm outline-none transition-all"
          style={{
            borderColor: selectedRoom ? color : "#e5e7eb",
            background: selectedRoom ? `${building?.color}88` : "white",
          }}
        />
        {selectedRoom && (
          <div
            className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
            style={{ background: color, color: "white" }}
          >
            ✓ {selectedRoom.buildingId}
          </div>
        )}
      </div>

      {open && (
        <div className="absolute z-50 mt-1 w-full bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
          {filtered.length === 0 ? (
            <div className="px-4 py-3 text-sm text-gray-400">Kein Raum gefunden</div>
          ) : (
            filtered.map((room) => {
              const b = BUILDINGS[room.buildingId];
              return (
                <button
                  key={room.id}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    setQuery(room.id);
                    onChange(room.id);
                    setOpen(false);
                  }}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0"
                >
                  <span
                    className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-lg text-xs"
                    style={{ background: b.color, color: b.textColor, fontWeight: 700 }}
                  >
                    {room.buildingId}
                  </span>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-gray-800">
                      {room.id}
                    </div>
                    <div className="text-xs text-gray-500 truncate">
                      {room.name} · {b.fullName} · {room.floor === 0 ? "EG" : `${room.floor}. OG`}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

const QUICK_LINKS = [
  { label: "Mensa", icon: "🍽️", from: "A001", to: "D001" },
  { label: "Bibliothek", icon: "📚", from: "A001", to: "C001" },
  { label: "Informatik", icon: "💻", from: "A001", to: "B101" },
  { label: "Chemielabor", icon: "🧪", from: "B001", to: "E001" },
];

export default function App() {
  const [fromId, setFromId] = useState("");
  const [toId, setToId] = useState("");
  const [route, setRoute] = useState<RouteResult | null>(null);
  const [activeTab, setActiveTab] = useState<"campus" | "indoor" | "directions">("campus");
  const [error, setError] = useState("");

  const fromRoom: Room | null = ROOMS[fromId] ?? null;
  const toRoom: Room | null = ROOMS[toId] ?? null;

  function handleRoute() {
    setError("");
    if (!fromId) { setError("Bitte einen Startraum eingeben."); return; }
    if (!toId) { setError("Bitte einen Zielraum eingeben."); return; }
    if (fromId === toId) { setError("Start- und Zielraum sind identisch."); return; }
    const result = findRoute(fromId, toId);
    if (!result) {
      setError("Kein Weg gefunden. Bitte überprüfen Sie die Raumkürzel.");
      return;
    }
    setRoute(result);
    setActiveTab(result.isSameBuilding ? "indoor" : "campus");
  }

  function handleQuick(from: string, to: string) {
    setFromId(from);
    setToId(to);
    setError("");
    const result = findRoute(from, to);
    if (result) {
      setRoute(result);
      setActiveTab(result.isSameBuilding ? "indoor" : "campus");
    }
  }

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #f0f4ff 0%, #e8f5e9 100%)" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-40 border-b border-white/40 backdrop-blur-md"
        style={{ background: "linear-gradient(90deg, #1e3a8a 0%, #1d4ed8 50%, #2563eb 100%)" }}
      >
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
            style={{ background: "rgba(255,255,255,0.15)" }}>
            🏛️
          </div>
          <div>
            <div className="text-white text-lg" style={{ fontWeight: 700, lineHeight: 1.2 }}>
              UniNav
            </div>
            <div className="text-blue-200 text-xs">Technische Universität Musterstadt</div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {route && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs text-white"
                style={{ background: "rgba(255,255,255,0.15)" }}>
                <span>⏱️ ~{route.estimatedMinutes} Min.</span>
                <span>·</span>
                <span>📏 ~{route.totalDistanceMeters} m</span>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 flex flex-col gap-6">
        {/* Search Card */}
        <div className="bg-white rounded-2xl shadow-md border border-white p-5">
          <h2 className="text-base mb-4" style={{ color: "#1e3a8a", fontWeight: 700 }}>
            🔍 Raumsuche
          </h2>

          <div className="flex flex-col sm:flex-row gap-4 items-end">
            <RoomSearch
              label="Startpunkt"
              value={fromId}
              onChange={setFromId}
              color="#22c55e"
              icon="📍"
            />

            {/* Swap button */}
            <button
              onClick={() => {
                const tmp = fromId;
                setFromId(toId);
                setToId(tmp);
                setRoute(null);
              }}
              className="flex-shrink-0 w-10 h-10 rounded-full border-2 border-gray-200 flex items-center justify-center hover:border-blue-400 hover:bg-blue-50 transition-all mb-0.5"
              title="Tauschen"
            >
              ⇄
            </button>

            <RoomSearch
              label="Zielraum"
              value={toId}
              onChange={setToId}
              color="#ef4444"
              icon="🎯"
            />

            <button
              onClick={handleRoute}
              className="flex-shrink-0 px-6 py-3 rounded-xl text-sm text-white transition-all hover:opacity-90 active:scale-95"
              style={{
                background: "linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)",
                fontWeight: 700,
                boxShadow: "0 4px 12px rgba(37,99,235,0.35)",
              }}
            >
              Route berechnen →
            </button>
          </div>

          {error && (
            <div className="mt-3 px-4 py-2 rounded-lg bg-red-50 border border-red-200 text-sm text-red-600">
              ⚠️ {error}
            </div>
          )}

          {/* Quick links */}
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="text-xs text-gray-400 self-center">Schnellnavigation:</span>
            {QUICK_LINKS.map((q) => (
              <button
                key={q.label}
                onClick={() => handleQuick(q.from, q.to)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs border border-gray-200 bg-gray-50 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 transition-all"
              >
                {q.icon} {q.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        {route && (
          <div className="flex flex-col gap-6">
            {/* Route Info Bar */}
            <div
              className="rounded-2xl p-4 border flex flex-wrap gap-4 items-center"
              style={{
                background: "linear-gradient(135deg, #eff6ff 0%, #f0fdf4 100%)",
                borderColor: "#bfdbfe",
              }}
            >
              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-sm"
                  style={{ background: BUILDINGS[route.fromBuilding].color, border: `2px solid ${BUILDINGS[route.fromBuilding].borderColor}` }}
                >
                  {route.fromBuilding}
                </div>
                <div>
                  <div className="text-xs text-gray-500">Von</div>
                  <div className="text-sm text-gray-800" style={{ fontWeight: 600 }}>{fromRoom?.id} – {fromRoom?.name}</div>
                </div>
              </div>
              <div className="text-blue-400 text-xl">→</div>
              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-sm"
                  style={{ background: BUILDINGS[route.toBuilding].color, border: `2px solid ${BUILDINGS[route.toBuilding].borderColor}` }}
                >
                  {route.toBuilding}
                </div>
                <div>
                  <div className="text-xs text-gray-500">Nach</div>
                  <div className="text-sm text-gray-800" style={{ fontWeight: 600 }}>{toRoom?.id} – {toRoom?.name}</div>
                </div>
              </div>
              <div className="ml-auto flex gap-4 text-center">
                <div>
                  <div className="text-xs text-gray-400">Entfernung</div>
                  <div className="text-sm" style={{ fontWeight: 700, color: "#1e3a8a" }}>~{route.totalDistanceMeters} m</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Gehzeit</div>
                  <div className="text-sm" style={{ fontWeight: 700, color: "#1e3a8a" }}>~{route.estimatedMinutes} Min.</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Typ</div>
                  <div className="text-sm" style={{ fontWeight: 700, color: route.isSameBuilding ? "#15803d" : "#1d4ed8" }}>
                    {route.isSameBuilding ? "Intern" : "Campus"}
                  </div>
                </div>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="flex gap-2 border-b border-gray-200">
              {!route.isSameBuilding && (
                <button
                  onClick={() => setActiveTab("campus")}
                  className={`px-5 py-2.5 text-sm rounded-t-xl border-b-2 transition-all ${
                    activeTab === "campus"
                      ? "border-blue-500 text-blue-700"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                  style={{ fontWeight: activeTab === "campus" ? 700 : 400 }}
                >
                  🗺️ Campuskarte
                </button>
              )}
              <button
                onClick={() => setActiveTab("indoor")}
                className={`px-5 py-2.5 text-sm rounded-t-xl border-b-2 transition-all ${
                  activeTab === "indoor"
                    ? "border-blue-500 text-blue-700"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
                style={{ fontWeight: activeTab === "indoor" ? 700 : 400 }}
              >
                🏢 Innenraum-Navigation
              </button>
              <button
                onClick={() => setActiveTab("directions")}
                className={`px-5 py-2.5 text-sm rounded-t-xl border-b-2 transition-all ${
                  activeTab === "directions"
                    ? "border-blue-500 text-blue-700"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
                style={{ fontWeight: activeTab === "directions" ? 700 : 400 }}
              >
                📋 Wegbeschreibung
              </button>
            </div>

            {/* Tab Content */}
            <div className="flex flex-col gap-4">
              {/* Campus Map Tab */}
              {activeTab === "campus" && !route.isSameBuilding && (
                <div className="flex flex-col gap-4">
                  <CampusMap
                    fromRoom={fromRoom}
                    toRoom={toRoom}
                    outdoorPath={route.outdoorPath}
                  />
                  <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                    <p className="text-sm text-blue-700">
                      💡 <strong>Tipp:</strong> Die blaue Linie zeigt Ihren optimalen Außenweg. 
                      Wechseln Sie zur <strong>Innenraum-Navigation</strong>, um den Weg innerhalb von{" "}
                      {BUILDINGS[route.toBuilding].fullName} zu sehen.
                    </p>
                  </div>
                </div>
              )}

              {/* Indoor Map Tab */}
              {activeTab === "indoor" && (
                <div className="flex flex-col gap-4">
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                    <h3 className="text-sm mb-4" style={{ fontWeight: 700, color: "#1e3a8a" }}>
                      🏢 Grundriss – {BUILDINGS[route.toBuilding].fullName}
                    </h3>
                    <IndoorMap
                      fromRoom={route.isSameBuilding ? fromRoom : null}
                      toRoom={toRoom}
                      isSameBuilding={route.isSameBuilding}
                    />
                  </div>
                  {!route.isSameBuilding && (
                    <div className="bg-purple-50 rounded-xl p-4 border border-purple-100">
                      <p className="text-sm text-purple-700">
                        💡 <strong>Tipp:</strong> Betreten Sie {BUILDINGS[route.toBuilding].name} und folgen Sie 
                        dem markierten Weg zum Raum <strong>{toRoom?.id}</strong>.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Directions Tab */}
              {activeTab === "directions" && (
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                  <h3 className="text-sm mb-4" style={{ fontWeight: 700, color: "#1e3a8a" }}>
                    📋 Schritt-für-Schritt-Wegbeschreibung
                  </h3>
                  <ol className="flex flex-col gap-3">
                    {route.directions.map((dir, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div
                          className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-xs text-white mt-0.5"
                          style={{
                            background: i === 0 ? "#22c55e" : i === route.directions.length - 1 ? "#ef4444" : "#2563eb",
                            fontWeight: 700,
                          }}
                        >
                          {i + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-lg leading-none">{dir.icon}</span>
                            <span className="text-sm text-gray-800" style={{ fontWeight: 600 }}>{dir.text}</span>
                          </div>
                          {dir.detail && (
                            <p className="text-xs text-gray-500 mt-0.5 ml-7">{dir.detail}</p>
                          )}
                        </div>
                        {i < route.directions.length - 1 && (
                          <div
                            className="absolute left-3.5 mt-7 w-0.5 h-3"
                            style={{ background: "#e5e7eb" }}
                          />
                        )}
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Empty State */}
        {!route && (
          <div className="flex flex-col gap-6">
            {/* Campus overview */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
              <h3 className="text-sm mb-4" style={{ fontWeight: 700, color: "#1e3a8a" }}>
                🗺️ Campusübersicht
              </h3>
              <CampusMap fromRoom={null} toRoom={null} outdoorPath={[]} />
            </div>

            {/* Building grid */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {Object.values(BUILDINGS).map((b) => (
                <div
                  key={b.id}
                  className="rounded-xl p-4 border"
                  style={{ background: b.color, borderColor: b.borderColor }}
                >
                  <div className="text-xs mb-1" style={{ color: b.textColor, fontWeight: 700 }}>
                    {b.name}
                  </div>
                  <div className="text-xs text-gray-600">{b.fullName}</div>
                  <div className="mt-2 text-xs text-gray-500">
                    {b.floors} Etage{b.floors > 1 ? "n" : ""}
                  </div>
                  <div className="mt-1 text-xs" style={{ color: b.textColor }}>
                    {b.description}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {Object.values(ROOMS)
                      .filter((r) => r.buildingId === b.id && r.floor === 0)
                      .slice(0, 3)
                      .map((r) => (
                        <button
                          key={r.id}
                          onClick={() => { setToId(r.id); }}
                          className="text-xs px-1.5 py-0.5 rounded border cursor-pointer hover:opacity-80 transition-opacity"
                          style={{
                            background: "white",
                            borderColor: b.borderColor,
                            color: b.textColor,
                          }}
                        >
                          {r.id}
                        </button>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-8 border-t border-gray-200 bg-white/60 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex flex-wrap gap-4 items-center justify-between text-xs text-gray-400">
          <span>UniNav · Technische Universität Musterstadt</span>
          <span>5 Gebäude · {Object.keys(ROOMS).length} Räume · Echtzeit-Navigation</span>
        </div>
      </footer>
    </div>
  );
}