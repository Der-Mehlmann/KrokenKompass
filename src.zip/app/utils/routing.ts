import {
  OUTDOOR_NODES,
  OUTDOOR_EDGES,
  BUILDING_ENTRANCES,
  BUILDINGS,
  ROOMS,
  Room,
} from "../data/campusData";

type Graph = Record<string, { neighbor: string; weight: number }[]>;

function buildGraph(): Graph {
  const graph: Graph = {};
  for (const nodeId of Object.keys(OUTDOOR_NODES)) {
    graph[nodeId] = [];
  }
  for (const [a, b] of OUTDOOR_EDGES) {
    const na = OUTDOOR_NODES[a];
    const nb = OUTDOOR_NODES[b];
    if (!na || !nb) continue;
    const dist = Math.sqrt((na.x - nb.x) ** 2 + (na.y - nb.y) ** 2);
    graph[a].push({ neighbor: b, weight: dist });
    graph[b].push({ neighbor: a, weight: dist });
  }
  return graph;
}

function dijkstra(
  graph: Graph,
  start: string
): { dist: Record<string, number>; prev: Record<string, string | null> } {
  const dist: Record<string, number> = {};
  const prev: Record<string, string | null> = {};

  for (const node of Object.keys(graph)) {
    dist[node] = Infinity;
    prev[node] = null;
  }
  dist[start] = 0;

  const unvisited = new Set(Object.keys(graph));

  while (unvisited.size > 0) {
    let u: string | null = null;
    let minDist = Infinity;
    for (const node of unvisited) {
      if (dist[node] < minDist) {
        minDist = dist[node];
        u = node;
      }
    }
    if (u === null || minDist === Infinity) break;
    unvisited.delete(u);

    for (const { neighbor, weight } of graph[u]) {
      const alt = dist[u] + weight;
      if (alt < dist[neighbor]) {
        dist[neighbor] = alt;
        prev[neighbor] = u;
      }
    }
  }
  return { dist, prev };
}

function reconstructPath(
  prev: Record<string, string | null>,
  end: string
): string[] {
  const path: string[] = [];
  let current: string | null = end;
  while (current !== null) {
    path.unshift(current);
    current = prev[current];
  }
  return path;
}

export interface Direction {
  icon: string;
  text: string;
  detail?: string;
}

export interface RouteResult {
  outdoorPath: string[];
  totalDistanceMeters: number;
  estimatedMinutes: number;
  fromBuilding: string;
  toBuilding: string;
  isSameBuilding: boolean;
  usedEntrance: string;
  directions: Direction[];
}

function getCardinalDir(
  from: { x: number; y: number },
  to: { x: number; y: number }
): string {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  if (Math.abs(dx) > Math.abs(dy)) {
    return dx > 0 ? "Osten" : "Westen";
  } else {
    return dy > 0 ? "Süden" : "Norden";
  }
}

function generateOutdoorDirections(
  path: string[],
  fromBuildingId: string,
  toBuildingId: string
): Direction[] {
  const fromB = BUILDINGS[fromBuildingId];
  const toB = BUILDINGS[toBuildingId];
  const dirs: Direction[] = [];

  // Find which entrance was used to exit
  const exitNode = path[0];
  const entranceNode = path[path.length - 1];

  // Determine exit direction label
  let exitLabel = "Ausgang";
  if (exitNode === "A_N" || exitNode === "B_N" || exitNode === "E_N")
    exitLabel = "Nordausgang";
  if (exitNode === "A_S" || exitNode === "B_S" || exitNode === "E_S")
    exitLabel = "Südausgang";
  if (exitNode === "A_E") exitLabel = "Ostausgang";
  if (exitNode === "B_W") exitLabel = "Westausgang";
  if (exitNode === "E_W") exitLabel = "Westausgang";

  dirs.push({
    icon: "🚪",
    text: `${fromB.fullName} verlassen`,
    detail: `Nutzen Sie den ${exitLabel} von ${fromB.name}`,
  });

  // Walk directions along path
  let i = 0;
  while (i < path.length - 1) {
    const cur = OUTDOOR_NODES[path[i]];
    const next = OUTDOOR_NODES[path[i + 1]];
    if (!cur || !next) { i++; continue; }

    const dir = getCardinalDir(cur, next);

    // Look ahead to extend straight segments
    let segEnd = i + 1;
    while (segEnd < path.length - 1) {
      const segCur = OUTDOOR_NODES[path[segEnd]];
      const segNext = OUTDOOR_NODES[path[segEnd + 1]];
      if (!segCur || !segNext) break;
      if (getCardinalDir(segCur, segNext) === dir) {
        segEnd++;
      } else {
        break;
      }
    }

    // Skip trivial junction segments
    if (path[i].startsWith("H1") || path[i].startsWith("H2") || path[i].startsWith("J")) {
      if (segEnd - i <= 1) {
        i = segEnd;
        continue;
      }
    }

    const distance = Math.round(
      Math.sqrt((next.x - cur.x) ** 2 + (next.y - cur.y) ** 2) * 1.2
    );
    const walkIcon = dir === "Norden" ? "⬆️" : dir === "Süden" ? "⬇️" : dir === "Osten" ? "➡️" : "⬅️";

    dirs.push({
      icon: walkIcon,
      text: `Richtung ${dir} gehen`,
      detail: `Folgen Sie dem Hauptweg`,
    });
    i = segEnd;
  }

  // Entrance direction
  let entryLabel = "Eingang";
  if (entranceNode === "A_N" || entranceNode === "B_N" || entranceNode === "E_N")
    entryLabel = "Nordeingang";
  if (entranceNode === "A_S" || entranceNode === "B_S" || entranceNode === "E_S")
    entryLabel = "Südeingang";
  if (entranceNode === "B_W") entryLabel = "Westeingang";
  if (entranceNode === "E_W") entryLabel = "Westeingang";

  dirs.push({
    icon: "🏛️",
    text: `${toB.fullName} betreten`,
    detail: `${toB.name} – ${toB.description} – durch ${entryLabel}`,
  });

  return dirs;
}

function generateIndoorDirections(fromRoom: Room, toRoom: Room): Direction[] {
  const dirs: Direction[] = [];
  const building = BUILDINGS[toRoom.buildingId];

  if (fromRoom.id === toRoom.id) {
    return [{ icon: "📍", text: "Sie sind bereits am Ziel!", detail: `Raum ${toRoom.id} – ${toRoom.name}` }];
  }

  dirs.push({
    icon: "🚶",
    text: "Gebäude betreten",
    detail: `${building.fullName} (${building.name})`,
  });

  if (fromRoom.floor !== toRoom.floor) {
    dirs.push({
      icon: "🪜",
      text: "Zur Treppe / zum Aufzug gehen",
      detail: "Am Ende des Korridors (rechts)",
    });
    const up = toRoom.floor > fromRoom.floor;
    const diff = Math.abs(toRoom.floor - fromRoom.floor);
    dirs.push({
      icon: up ? "⬆️" : "⬇️",
      text: `${diff} Etage${diff > 1 ? "n" : ""} ${up ? "hoch" : "runter"} gehen`,
      detail: `Ziel: ${toRoom.floor}. Obergeschoss (OG ${toRoom.floor})`,
    });
  }

  const sideText = toRoom.side === "N" ? "linke Seite (Nord)" : "rechte Seite (Süd)";
  dirs.push({
    icon: "🚶",
    text: "Korridor entlanggehen",
    detail: `Raum ${toRoom.id} befindet sich auf der ${sideText}`,
  });

  dirs.push({
    icon: "📍",
    text: `Raum ${toRoom.id} betreten`,
    detail: toRoom.name,
  });

  return dirs;
}

export function findRoute(
  fromRoomId: string,
  toRoomId: string
): RouteResult | null {
  const fromRoom = ROOMS[fromRoomId];
  const toRoom = ROOMS[toRoomId];

  if (!fromRoom || !toRoom) return null;

  const fromBuildingId = fromRoom.buildingId;
  const toBuildingId = toRoom.buildingId;

  // Same building routing
  if (fromBuildingId === toBuildingId) {
    return {
      outdoorPath: [],
      totalDistanceMeters: Math.round(
        (Math.abs(fromRoom.floor - toRoom.floor) * 4 +
          Math.abs(fromRoom.position - toRoom.position) * 15 +
          20) * 1.2
      ),
      estimatedMinutes: Math.max(1, Math.round(
        (Math.abs(fromRoom.floor - toRoom.floor) * 0.5 +
          Math.abs(fromRoom.position - toRoom.position) * 0.2 +
          0.5)
      )),
      fromBuilding: fromBuildingId,
      toBuilding: toBuildingId,
      isSameBuilding: true,
      usedEntrance: BUILDING_ENTRANCES[fromBuildingId][0],
      directions: generateIndoorDirections(fromRoom, toRoom),
    };
  }

  // Cross-building outdoor routing
  const graph = buildGraph();
  let bestPath: string[] = [];
  let bestDist = Infinity;
  let bestEntrance = "";

  for (const startNode of BUILDING_ENTRANCES[fromBuildingId]) {
    if (!graph[startNode]) continue;
    const { dist, prev } = dijkstra(graph, startNode);

    for (const endNode of BUILDING_ENTRANCES[toBuildingId]) {
      if (dist[endNode] < bestDist) {
        bestDist = dist[endNode];
        bestPath = reconstructPath(prev, endNode);
        bestEntrance = endNode;
      }
    }
  }

  if (bestPath.length === 0) return null;

  const distMeters = Math.round(bestDist * 1.2);
  const minutes = Math.max(1, Math.round(distMeters / 80));

  const outdoorDirs = generateOutdoorDirections(bestPath, fromBuildingId, toBuildingId);
  const indoorDirs = generateIndoorDirections(
    { ...toRoom, floor: 0, position: 0, side: "S" }, // simulate entering at floor 0
    toRoom
  );

  return {
    outdoorPath: bestPath,
    totalDistanceMeters: distMeters,
    estimatedMinutes: minutes,
    fromBuilding: fromBuildingId,
    toBuilding: toBuildingId,
    isSameBuilding: false,
    usedEntrance: bestEntrance,
    directions: [...outdoorDirs, ...indoorDirs],
  };
}
