import { useEffect, useState } from "react";
import { BUILDINGS, ROOMS, Room } from "../data/campusData";

interface IndoorMapProps {
  fromRoom: Room | null;
  toRoom: Room | null;
  isSameBuilding: boolean;
}

// Indoor SVG layout constants
const SVG_W = 620;
const SVG_H = 310;
const CORRIDOR_Y1 = 115; // top of corridor
const CORRIDOR_Y2 = 175; // bottom of corridor
const CORRIDOR_X_START = 48;
const CORRIDOR_X_END = 530;
const STAIRS_X = 540;
const ROOM_WIDTH = 115;
const ROOM_HEIGHT = 93;
const ROOM_GAP = 8;
const ROOM_Y_NORTH = 22; // top of north rooms
const ROOM_Y_SOUTH = 177; // top of south rooms (= CORRIDOR_Y2 + 2)
const NUM_POSITIONS = 4;

// Room position: x center for each position slot
function roomCenterX(pos: number): number {
  return CORRIDOR_X_START + pos * (ROOM_WIDTH + ROOM_GAP) + ROOM_WIDTH / 2;
}

interface PathPoint {
  x: number;
  y: number;
}

function buildIndoorPath(
  fromRoom: Room | null,
  toRoom: Room | null,
  isSameBuilding: boolean,
  displayFloor: number
): PathPoint[] {
  if (!toRoom) return [];

  const corrMidY = (CORRIDOR_Y1 + CORRIDOR_Y2) / 2;
  const entranceX = roomCenterX(0) - 60; // entrance is near west end
  const stairsCorX = STAIRS_X + 20;
  const toRoomCX = roomCenterX(toRoom.position);
  const toRoomY =
    toRoom.side === "N"
      ? ROOM_Y_NORTH + ROOM_HEIGHT / 2
      : ROOM_Y_SOUTH + ROOM_HEIGHT / 2;

  const isTargetFloor = displayFloor === toRoom.floor;

  if (isSameBuilding && fromRoom) {
    // Navigate from one room to another in same building
    const fromRoomCX = roomCenterX(fromRoom.position);
    const fromRoomY =
      fromRoom.side === "N"
        ? ROOM_Y_NORTH + ROOM_HEIGHT / 2
        : ROOM_Y_SOUTH + ROOM_HEIGHT / 2;

    if (fromRoom.floor === toRoom.floor && displayFloor === fromRoom.floor) {
      // Same floor path
      return [
        { x: fromRoomCX, y: fromRoomY },
        { x: fromRoomCX, y: corrMidY },
        { x: toRoomCX, y: corrMidY },
        { x: toRoomCX, y: toRoomY },
      ];
    }

    if (displayFloor === fromRoom.floor) {
      // Show path to stairs from source floor
      return [
        { x: fromRoomCX, y: fromRoomY },
        { x: fromRoomCX, y: corrMidY },
        { x: stairsCorX, y: corrMidY },
      ];
    }

    if (isTargetFloor) {
      // Show path from stairs to destination on target floor
      return [
        { x: stairsCorX, y: corrMidY },
        { x: toRoomCX, y: corrMidY },
        { x: toRoomCX, y: toRoomY },
      ];
    }
    return [];
  }

  // Cross-building: entering from outside, going to toRoom
  if (!isTargetFloor && toRoom.floor !== 0) {
    if (displayFloor === 0) {
      // Ground floor: enter and go to stairs
      return [
        { x: entranceX, y: SVG_H - 2 },
        { x: entranceX, y: corrMidY },
        { x: stairsCorX, y: corrMidY },
      ];
    }
    if (isTargetFloor) {
      return [
        { x: stairsCorX, y: corrMidY },
        { x: toRoomCX, y: corrMidY },
        { x: toRoomCX, y: toRoomY },
      ];
    }
    return [];
  }

  // Target is on this floor (ground floor or already at right floor)
  if (isTargetFloor) {
    return [
      { x: entranceX, y: SVG_H - 2 },
      { x: entranceX, y: corrMidY },
      { x: toRoomCX, y: corrMidY },
      { x: toRoomCX, y: toRoomY },
    ];
  }
  return [];
}

export function IndoorMap({ fromRoom, toRoom, isSameBuilding }: IndoorMapProps) {
  const [displayFloor, setDisplayFloor] = useState(0);
  const [pathAnimated, setPathAnimated] = useState(false);

  const targetRoom = toRoom;
  const buildingId = targetRoom?.buildingId;
  const building = buildingId ? BUILDINGS[buildingId] : null;

  useEffect(() => {
    if (targetRoom) {
      setDisplayFloor(isSameBuilding && fromRoom ? fromRoom.floor : 0);
      setPathAnimated(false);
      const t = setTimeout(() => setPathAnimated(true), 200);
      return () => clearTimeout(t);
    }
  }, [targetRoom?.id, fromRoom?.id]);

  if (!targetRoom || !building) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-gray-400">
        <div className="text-5xl mb-3">🗺️</div>
        <p className="text-sm">Wählen Sie Start- und Zielraum für die Innenraumnavigation</p>
      </div>
    );
  }

  // Get all rooms on this building + floor
  const roomsOnFloor = Object.values(ROOMS).filter(
    (r) => r.buildingId === buildingId && r.floor === displayFloor
  );

  const numFloors = building.floors;
  const path = buildIndoorPath(fromRoom, targetRoom, isSameBuilding, displayFloor);

  // Build SVG polyline string
  const pathStr = path.map((p) => `${p.x},${p.y}`).join(" ");
  const pathLength = path.reduce((acc, p, i) => {
    if (i === 0) return 0;
    const prev = path[i - 1];
    return acc + Math.sqrt((p.x - prev.x) ** 2 + (p.y - prev.y) ** 2);
  }, 0);

  const isFromFloor = isSameBuilding && fromRoom?.floor === displayFloor;
  const isToFloor = targetRoom.floor === displayFloor;

  return (
    <div className="flex flex-col gap-3">
      {/* Floor selector */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-gray-500 font-medium">Etage:</span>
        {Array.from({ length: numFloors }, (_, i) => (
          <button
            key={i}
            onClick={() => {
              setDisplayFloor(i);
              setPathAnimated(false);
              setTimeout(() => setPathAnimated(true), 100);
            }}
            className={`px-3 py-1 rounded-full text-xs border transition-all ${
              displayFloor === i
                ? "border-blue-500 text-blue-700"
                : "border-gray-200 text-gray-500 hover:border-gray-400"
            }`}
            style={{
              background:
                displayFloor === i
                  ? `${building.color}`
                  : "white",
              fontWeight: displayFloor === i ? 700 : 400,
            }}
          >
            {i === 0 ? "EG" : `${i}. OG`}
            {i === targetRoom.floor && " 🎯"}
            {isSameBuilding && fromRoom?.floor === i && " 📍"}
          </button>
        ))}
        <span className="ml-auto text-xs text-gray-400">
          {building.fullName}
        </span>
      </div>

      {/* SVG Floor Plan */}
      <div className="relative overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <svg viewBox={`0 0 ${SVG_W} ${SVG_H}`} className="w-full" style={{ display: "block" }}>
          {/* Floor background */}
          <rect x="0" y="0" width={SVG_W} height={SVG_H} fill="#f8fafc" />

          {/* Outer walls */}
          <rect
            x="2"
            y="2"
            width={SVG_W - 4}
            height={SVG_H - 4}
            rx="8"
            fill={building.color}
            stroke={building.borderColor}
            strokeWidth="3"
          />

          {/* North room area background */}
          <rect
            x={CORRIDOR_X_START}
            y={ROOM_Y_NORTH}
            width={CORRIDOR_X_END - CORRIDOR_X_START}
            height={ROOM_HEIGHT}
            rx="4"
            fill="white"
            opacity="0.4"
          />
          {/* South room area background */}
          <rect
            x={CORRIDOR_X_START}
            y={ROOM_Y_SOUTH}
            width={CORRIDOR_X_END - CORRIDOR_X_START}
            height={ROOM_HEIGHT}
            rx="4"
            fill="white"
            opacity="0.4"
          />

          {/* === MAIN CORRIDOR === */}
          <rect
            x={CORRIDOR_X_START}
            y={CORRIDOR_Y1}
            width={CORRIDOR_X_END - CORRIDOR_X_START}
            height={CORRIDOR_Y2 - CORRIDOR_Y1}
            fill="#e2e8f0"
            stroke="#cbd5e1"
            strokeWidth="1"
          />
          <text
            x={(CORRIDOR_X_START + CORRIDOR_X_END) / 2}
            y={(CORRIDOR_Y1 + CORRIDOR_Y2) / 2 + 4}
            textAnchor="middle"
            fontSize="9"
            fill="#94a3b8"
            fontFamily="system-ui"
          >
            ← Flur / Korridor →
          </text>

          {/* === STAIRCASE === */}
          <rect
            x={STAIRS_X}
            y={ROOM_Y_NORTH}
            width={60}
            height={ROOM_HEIGHT + (CORRIDOR_Y2 - CORRIDOR_Y1) + ROOM_HEIGHT}
            rx="4"
            fill="#f1f5f9"
            stroke="#94a3b8"
            strokeWidth="1.5"
          />
          {/* Stair lines */}
          {Array.from({ length: 6 }, (_, i) => (
            <line
              key={i}
              x1={STAIRS_X + 6}
              y1={ROOM_Y_NORTH + 14 + i * 14}
              x2={STAIRS_X + 54}
              y2={ROOM_Y_NORTH + 14 + i * 14}
              stroke="#94a3b8"
              strokeWidth="1"
            />
          ))}
          <text
            x={STAIRS_X + 30}
            y={SVG_H / 2 + 4}
            textAnchor="middle"
            fontSize="8"
            fill="#64748b"
            fontFamily="system-ui"
          >
            🪜
          </text>
          <text
            x={STAIRS_X + 30}
            y={SVG_H / 2 + 16}
            textAnchor="middle"
            fontSize="7"
            fill="#94a3b8"
            fontFamily="system-ui"
          >
            Treppe
          </text>

          {/* === ENTRANCE DOOR === */}
          <rect
            x={CORRIDOR_X_START + 8}
            y={SVG_H - 12}
            width={40}
            height={12}
            rx="2"
            fill="#fbbf24"
            stroke="#d97706"
            strokeWidth="1.5"
          />
          <text
            x={CORRIDOR_X_START + 28}
            y={SVG_H - 4}
            textAnchor="middle"
            fontSize="7"
            fill="white"
            fontWeight="bold"
            fontFamily="system-ui"
          >
            Eingang
          </text>

          {/* === ROOM RENDERING === */}
          {Array.from({ length: NUM_POSITIONS }, (_, pos) => {
            const northRoom = roomsOnFloor.find((r) => r.position === pos && r.side === "N");
            const southRoom = roomsOnFloor.find((r) => r.position === pos && r.side === "S");
            const rx = CORRIDOR_X_START + pos * (ROOM_WIDTH + ROOM_GAP);

            return (
              <g key={pos}>
                {/* North room */}
                <g>
                  {(() => {
                    const isTarget = northRoom?.id === targetRoom?.id;
                    const isFrom = northRoom?.id === fromRoom?.id;
                    return (
                      <>
                        <rect
                          x={rx}
                          y={ROOM_Y_NORTH}
                          width={ROOM_WIDTH}
                          height={ROOM_HEIGHT}
                          rx="4"
                          fill={isTarget ? "#fef2f2" : isFrom ? "#f0fdf4" : "white"}
                          stroke={
                            isTarget
                              ? "#ef4444"
                              : isFrom
                              ? "#22c55e"
                              : "#d1d5db"
                          }
                          strokeWidth={isTarget || isFrom ? 2.5 : 1}
                        />
                        {/* Door slot at bottom of north room */}
                        <rect
                          x={rx + ROOM_WIDTH / 2 - 10}
                          y={ROOM_Y_NORTH + ROOM_HEIGHT - 2}
                          width={20}
                          height={4}
                          fill="#94a3b8"
                        />
                        <text
                          x={rx + ROOM_WIDTH / 2}
                          y={ROOM_Y_NORTH + 28}
                          textAnchor="middle"
                          fontSize="11"
                          fontWeight="700"
                          fill={isTarget ? "#b91c1c" : isFrom ? "#15803d" : "#374151"}
                          fontFamily="system-ui"
                        >
                          {northRoom?.id ?? `–`}
                        </text>
                        {isTarget && (
                          <text
                            x={rx + ROOM_WIDTH / 2}
                            y={ROOM_Y_NORTH + 44}
                            textAnchor="middle"
                            fontSize="16"
                          >
                            🎯
                          </text>
                        )}
                        {isFrom && (
                          <text
                            x={rx + ROOM_WIDTH / 2}
                            y={ROOM_Y_NORTH + 44}
                            textAnchor="middle"
                            fontSize="16"
                          >
                            📍
                          </text>
                        )}
                        <text
                          x={rx + ROOM_WIDTH / 2}
                          y={ROOM_Y_NORTH + (isTarget || isFrom ? 64 : 50)}
                          textAnchor="middle"
                          fontSize="7.5"
                          fill="#6b7280"
                          fontFamily="system-ui"
                        >
                          {northRoom
                            ? northRoom.name.length > 14
                              ? northRoom.name.substring(0, 13) + "…"
                              : northRoom.name
                            : ""}
                        </text>
                        {/* Position number indicator at top */}
                        <text
                          x={rx + 7}
                          y={ROOM_Y_NORTH + 10}
                          fontSize="7"
                          fill="#cbd5e1"
                          fontFamily="system-ui"
                        >
                          N
                        </text>
                      </>
                    );
                  })()}
                </g>

                {/* South room */}
                <g>
                  {(() => {
                    const isTarget = southRoom?.id === targetRoom?.id;
                    const isFrom = southRoom?.id === fromRoom?.id;
                    return (
                      <>
                        <rect
                          x={rx}
                          y={ROOM_Y_SOUTH}
                          width={ROOM_WIDTH}
                          height={ROOM_HEIGHT}
                          rx="4"
                          fill={isTarget ? "#fef2f2" : isFrom ? "#f0fdf4" : "white"}
                          stroke={
                            isTarget
                              ? "#ef4444"
                              : isFrom
                              ? "#22c55e"
                              : "#d1d5db"
                          }
                          strokeWidth={isTarget || isFrom ? 2.5 : 1}
                        />
                        {/* Door slot at top of south room */}
                        <rect
                          x={rx + ROOM_WIDTH / 2 - 10}
                          y={ROOM_Y_SOUTH - 2}
                          width={20}
                          height={4}
                          fill="#94a3b8"
                        />
                        <text
                          x={rx + ROOM_WIDTH / 2}
                          y={ROOM_Y_SOUTH + 22}
                          textAnchor="middle"
                          fontSize="11"
                          fontWeight="700"
                          fill={isTarget ? "#b91c1c" : isFrom ? "#15803d" : "#374151"}
                          fontFamily="system-ui"
                        >
                          {southRoom?.id ?? `–`}
                        </text>
                        {isTarget && (
                          <text
                            x={rx + ROOM_WIDTH / 2}
                            y={ROOM_Y_SOUTH + 42}
                            textAnchor="middle"
                            fontSize="16"
                          >
                            🎯
                          </text>
                        )}
                        {isFrom && (
                          <text
                            x={rx + ROOM_WIDTH / 2}
                            y={ROOM_Y_SOUTH + 42}
                            textAnchor="middle"
                            fontSize="16"
                          >
                            📍
                          </text>
                        )}
                        <text
                          x={rx + ROOM_WIDTH / 2}
                          y={ROOM_Y_SOUTH + (isTarget || isFrom ? 62 : 46)}
                          textAnchor="middle"
                          fontSize="7.5"
                          fill="#6b7280"
                          fontFamily="system-ui"
                        >
                          {southRoom
                            ? southRoom.name.length > 14
                              ? southRoom.name.substring(0, 13) + "…"
                              : southRoom.name
                            : ""}
                        </text>
                        <text
                          x={rx + 7}
                          y={ROOM_Y_SOUTH + 10}
                          fontSize="7"
                          fill="#cbd5e1"
                          fontFamily="system-ui"
                        >
                          S
                        </text>
                      </>
                    );
                  })()}
                </g>
              </g>
            );
          })}

          {/* === PATH OVERLAY === */}
          {pathStr && (
            <>
              {/* Glow effect */}
              <polyline
                points={pathStr}
                fill="none"
                stroke="#93c5fd"
                strokeWidth="12"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.35"
              />
              {/* Main path line */}
              <polyline
                points={pathStr}
                fill="none"
                stroke="#2563eb"
                strokeWidth="4.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray={`${pathLength} ${pathLength}`}
                strokeDashoffset={pathAnimated ? 0 : pathLength}
                style={{
                  transition: pathAnimated
                    ? `stroke-dashoffset ${Math.max(0.6, pathLength / 250)}s ease-in-out`
                    : "none",
                }}
              />
              {/* Waypoint dots */}
              {path.map((p, i) => (
                <circle
                  key={i}
                  cx={p.x}
                  cy={p.y}
                  r={i === 0 || i === path.length - 1 ? 7 : 4}
                  fill={
                    i === 0
                      ? "#22c55e"
                      : i === path.length - 1
                      ? "#ef4444"
                      : "#2563eb"
                  }
                  opacity={pathAnimated ? 1 : 0}
                  style={{ transition: `opacity 0.3s ${i * 0.1}s` }}
                />
              ))}
            </>
          )}

          {/* Floor label */}
          <rect x={SVG_W - 82} y={SVG_H - 28} width={78} height={22} rx="5" fill="white" opacity="0.8" />
          <text
            x={SVG_W - 43}
            y={SVG_H - 12}
            textAnchor="middle"
            fontSize="10"
            fill="#374151"
            fontWeight="600"
            fontFamily="system-ui"
          >
            {displayFloor === 0 ? "Erdgeschoss" : `${displayFloor}. Obergeschoss`}
          </text>
        </svg>
      </div>

      {/* Floor info */}
      <div className="flex gap-2 text-xs text-gray-500 flex-wrap">
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded-full bg-green-500"></span>
          {isSameBuilding ? "Ihr Standort" : "Eingang"}
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded-full bg-red-500"></span>
          Zielraum: {targetRoom.id}
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-8 h-1 rounded bg-blue-500"></span>
          Ihr Weg
        </span>
      </div>
    </div>
  );
}
