import { useEffect, useRef, useState } from "react";
import { BUILDINGS, OUTDOOR_NODES, Room } from "../data/campusData";

interface CampusMapProps {
  fromRoom: Room | null;
  toRoom: Room | null;
  outdoorPath: string[];
}

export function CampusMap({ fromRoom, toRoom, outdoorPath }: CampusMapProps) {
  const pathRef = useRef<SVGPolylineElement>(null);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    setAnimated(false);
    if (outdoorPath.length > 0) {
      const timer = setTimeout(() => setAnimated(true), 100);
      return () => clearTimeout(timer);
    }
  }, [outdoorPath]);

  // Build polyline points from path node IDs
  const pathPoints = outdoorPath
    .map((id) => OUTDOOR_NODES[id])
    .filter(Boolean)
    .map((n) => `${n.x},${n.y}`)
    .join(" ");

  // Calculate total path length for animation
  const pathCoords = outdoorPath
    .map((id) => OUTDOOR_NODES[id])
    .filter(Boolean);

  let totalLength = 0;
  for (let i = 0; i < pathCoords.length - 1; i++) {
    const a = pathCoords[i];
    const b = pathCoords[i + 1];
    totalLength += Math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2);
  }

  const fromBuildingId = fromRoom?.buildingId;
  const toBuildingId = toRoom?.buildingId;

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
      <svg
        viewBox="0 0 900 620"
        className="w-full"
        style={{ display: "block" }}
      >
        {/* === BACKGROUND === */}
        <defs>
          <pattern id="grass" patternUnits="userSpaceOnUse" width="20" height="20">
            <rect width="20" height="20" fill="#d1fae5" />
            <circle cx="5" cy="5" r="1.5" fill="#a7f3d0" opacity="0.4" />
            <circle cx="15" cy="15" r="1" fill="#a7f3d0" opacity="0.3" />
          </pattern>
          <filter id="buildingShadow" x="-5%" y="-5%" width="115%" height="115%">
            <feDropShadow dx="2" dy="3" stdDeviation="3" floodOpacity="0.15" />
          </filter>
          <marker
            id="arrowBlue"
            markerWidth="8"
            markerHeight="8"
            refX="6"
            refY="3"
            orient="auto"
          >
            <path d="M0,0 L0,6 L8,3 z" fill="#3b82f6" />
          </marker>
        </defs>

        {/* Grass background */}
        <rect x="0" y="0" width="900" height="620" fill="url(#grass)" />

        {/* Campus border */}
        <rect
          x="30"
          y="30"
          width="840"
          height="560"
          rx="12"
          fill="none"
          stroke="#86efac"
          strokeWidth="3"
          strokeDasharray="12 6"
        />

        {/* === WALKWAYS === */}
        {/* Main north horizontal (H1) */}
        <rect x="60" y="205" width="795" height="12" rx="3" fill="#cbd5e1" />
        {/* Main south horizontal (H2) */}
        <rect x="60" y="450" width="795" height="12" rx="3" fill="#cbd5e1" />
        {/* Vertical V_W (east of A) */}
        <rect x="290" y="211" width="11" height="244" fill="#cbd5e1" />
        {/* Vertical V_E (west of E) */}
        <rect x="645" y="211" width="11" height="244" fill="#cbd5e1" />
        {/* H_MID_W: between A east and B west */}
        <rect x="296" y="309" width="90" height="11" rx="2" fill="#cbd5e1" />
        {/* H_MID_E: between B east and E west */}
        <rect x="584" y="309" width="67" height="11" rx="2" fill="#cbd5e1" />

        {/* Short building connectors */}
        {/* C → H1 */}
        <rect x="173" y="185" width="9" height="22" rx="2" fill="#cbd5e1" />
        {/* A_N → H1 */}
        <rect x="176" y="211" width="9" height="30" rx="2" fill="#cbd5e1" />
        {/* A_S → H2 */}
        <rect x="176" y="393" width="9" height="58" rx="2" fill="#cbd5e1" />
        {/* B_N → H1 */}
        <rect x="481" y="211" width="9" height="20" rx="2" fill="#cbd5e1" />
        {/* B_S → H2 */}
        <rect x="481" y="388" width="9" height="63" rx="2" fill="#cbd5e1" />
        {/* D_N → H2 */}
        <rect x="153" y="453" width="9" height="23" rx="2" fill="#cbd5e1" />
        {/* E_N → H1 */}
        <rect x="741" y="211" width="9" height="25" rx="2" fill="#cbd5e1" />
        {/* E_S → H2 */}
        <rect x="741" y="383" width="9" height="68" rx="2" fill="#cbd5e1" />

        {/* Walkway edge highlights */}
        <rect x="60" y="205" width="795" height="2" rx="1" fill="#94a3b8" opacity="0.4" />
        <rect x="60" y="462" width="795" height="2" rx="1" fill="#94a3b8" opacity="0.4" />

        {/* === BUILDINGS === */}
        {Object.values(BUILDINGS).map((b) => {
          const isFrom = b.id === fromBuildingId;
          const isTo = b.id === toBuildingId;
          const highlight = isFrom || isTo;

          return (
            <g key={b.id} filter="url(#buildingShadow)">
              {/* Building fill */}
              <rect
                x={b.x}
                y={b.y}
                width={b.width}
                height={b.height}
                rx="6"
                fill={b.color}
                stroke={highlight ? (isTo ? "#ef4444" : "#22c55e") : b.borderColor}
                strokeWidth={highlight ? 3 : 2}
              />
              {/* Roof line decoration */}
              <rect
                x={b.x + 2}
                y={b.y + 2}
                width={b.width - 4}
                height={8}
                rx="4"
                fill={b.borderColor}
                opacity="0.25"
              />

              {/* Building name tag */}
              <rect
                x={b.x + b.width / 2 - 42}
                y={b.y + b.height / 2 - 22}
                width={84}
                height={44}
                rx="6"
                fill="white"
                opacity="0.85"
              />
              <text
                x={b.x + b.width / 2}
                y={b.y + b.height / 2 - 6}
                textAnchor="middle"
                fontSize="13"
                fontWeight="700"
                fill={b.textColor}
                fontFamily="system-ui, sans-serif"
              >
                {b.name}
              </text>
              <text
                x={b.x + b.width / 2}
                y={b.y + b.height / 2 + 10}
                textAnchor="middle"
                fontSize="8.5"
                fill="#64748b"
                fontFamily="system-ui, sans-serif"
              >
                {b.description}
              </text>

              {/* Floor indicator dots */}
              {Array.from({ length: b.floors }).map((_, i) => (
                <circle
                  key={i}
                  cx={b.x + b.width / 2 - ((b.floors - 1) * 5) + i * 10}
                  cy={b.y + b.height - 14}
                  r="3"
                  fill={b.borderColor}
                  opacity="0.6"
                />
              ))}

              {/* Highlight ring for from/to buildings */}
              {highlight && (
                <rect
                  x={b.x - 4}
                  y={b.y - 4}
                  width={b.width + 8}
                  height={b.height + 8}
                  rx="9"
                  fill="none"
                  stroke={isTo ? "#ef4444" : "#22c55e"}
                  strokeWidth="2.5"
                  strokeDasharray="8 4"
                  opacity="0.8"
                />
              )}
            </g>
          );
        })}

        {/* === ROUTE PATH === */}
        {pathPoints && (
          <>
            {/* Path shadow/glow */}
            <polyline
              points={pathPoints}
              fill="none"
              stroke="#93c5fd"
              strokeWidth="10"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.4"
            />
            {/* Main animated path */}
            <polyline
              ref={pathRef}
              points={pathPoints}
              fill="none"
              stroke="#2563eb"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray={`${totalLength} ${totalLength}`}
              strokeDashoffset={animated ? 0 : totalLength}
              style={{
                transition: animated
                  ? `stroke-dashoffset ${Math.max(1, totalLength / 200)}s ease-in-out`
                  : "none",
              }}
              markerEnd="url(#arrowBlue)"
            />
            {/* Direction dots along path */}
            {pathCoords.map((node, i) => {
              if (i === 0 || i === pathCoords.length - 1) return null;
              return (
                <circle
                  key={i}
                  cx={node.x}
                  cy={node.y}
                  r="4"
                  fill="#2563eb"
                  opacity={animated ? 0.7 : 0}
                  style={{ transition: "opacity 0.5s 0.8s" }}
                />
              );
            })}
          </>
        )}

        {/* === MARKERS === */}
        {/* Start marker (from room) */}
        {fromRoom && fromBuildingId && BUILDINGS[fromBuildingId] && (
          <g>
            <circle
              cx={BUILDINGS[fromBuildingId].x + BUILDINGS[fromBuildingId].width / 2}
              cy={BUILDINGS[fromBuildingId].y + BUILDINGS[fromBuildingId].height / 2}
              r="18"
              fill="#22c55e"
              opacity="0.25"
            />
            <circle
              cx={BUILDINGS[fromBuildingId].x + BUILDINGS[fromBuildingId].width / 2}
              cy={BUILDINGS[fromBuildingId].y + BUILDINGS[fromBuildingId].height / 2}
              r="10"
              fill="#22c55e"
            />
            <text
              x={BUILDINGS[fromBuildingId].x + BUILDINGS[fromBuildingId].width / 2}
              y={BUILDINGS[fromBuildingId].y + BUILDINGS[fromBuildingId].height / 2 + 4}
              textAnchor="middle"
              fontSize="10"
              fill="white"
              fontWeight="bold"
              fontFamily="system-ui, sans-serif"
            >
              S
            </text>
            <text
              x={BUILDINGS[fromBuildingId].x + BUILDINGS[fromBuildingId].width / 2}
              y={BUILDINGS[fromBuildingId].y - 12}
              textAnchor="middle"
              fontSize="10"
              fill="#15803d"
              fontWeight="600"
              fontFamily="system-ui, sans-serif"
            >
              Start: {fromRoom.id}
            </text>
          </g>
        )}

        {/* Destination marker (to room) */}
        {toRoom && toBuildingId && BUILDINGS[toBuildingId] && (
          <g>
            <circle
              cx={BUILDINGS[toBuildingId].x + BUILDINGS[toBuildingId].width / 2}
              cy={BUILDINGS[toBuildingId].y + BUILDINGS[toBuildingId].height / 2}
              r="18"
              fill="#ef4444"
              opacity="0.25"
            />
            <circle
              cx={BUILDINGS[toBuildingId].x + BUILDINGS[toBuildingId].width / 2}
              cy={BUILDINGS[toBuildingId].y + BUILDINGS[toBuildingId].height / 2}
              r="10"
              fill="#ef4444"
            />
            <text
              x={BUILDINGS[toBuildingId].x + BUILDINGS[toBuildingId].width / 2}
              y={BUILDINGS[toBuildingId].y + BUILDINGS[toBuildingId].height / 2 + 4}
              textAnchor="middle"
              fontSize="10"
              fill="white"
              fontWeight="bold"
              fontFamily="system-ui, sans-serif"
            >
              Z
            </text>
            <text
              x={BUILDINGS[toBuildingId].x + BUILDINGS[toBuildingId].width / 2}
              y={BUILDINGS[toBuildingId].y - 12}
              textAnchor="middle"
              fontSize="10"
              fill="#b91c1c"
              fontWeight="600"
              fontFamily="system-ui, sans-serif"
            >
              Ziel: {toRoom.id}
            </text>
          </g>
        )}

        {/* Compass */}
        <g transform="translate(855, 55)">
          <circle cx="0" cy="0" r="22" fill="white" opacity="0.9" stroke="#d1d5db" strokeWidth="1.5" />
          <text x="0" y="-7" textAnchor="middle" fontSize="9" fill="#374151" fontFamily="system-ui" fontWeight="600">N</text>
          <text x="0" y="13" textAnchor="middle" fontSize="9" fill="#9ca3af" fontFamily="system-ui">S</text>
          <text x="-12" y="3" textAnchor="middle" fontSize="9" fill="#9ca3af" fontFamily="system-ui">W</text>
          <text x="12" y="3" textAnchor="middle" fontSize="9" fill="#9ca3af" fontFamily="system-ui">O</text>
          <polygon points="0,-14 3,-4 0,-7 -3,-4" fill="#ef4444" />
          <polygon points="0,14 3,4 0,7 -3,4" fill="#6b7280" />
        </g>

        {/* Legend */}
        <g transform="translate(32, 560)">
          <rect x="0" y="-18" width="220" height="42" rx="6" fill="white" opacity="0.88" />
          <circle cx="14" cy="0" r="7" fill="#22c55e" />
          <text x="25" y="4" fontSize="9" fill="#374151" fontFamily="system-ui">Startpunkt</text>
          <circle cx="90" cy="0" r="7" fill="#ef4444" />
          <text x="101" y="4" fontSize="9" fill="#374151" fontFamily="system-ui">Zielraum</text>
          <line x1="155" y1="0" x2="185" y2="0" stroke="#2563eb" strokeWidth="3" strokeLinecap="round" />
          <text x="190" y="4" fontSize="9" fill="#374151" fontFamily="system-ui">Route</text>
        </g>
      </svg>
    </div>
  );
}
