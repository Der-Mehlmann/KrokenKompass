export interface Building {
  id: string;
  name: string;
  fullName: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  borderColor: string;
  textColor: string;
  floors: number;
  description: string;
}

export interface Room {
  id: string;
  buildingId: string;
  floor: number;
  name: string;
  position: number; // 0-3, left to right along corridor
  side: "N" | "S"; // north or south of corridor
}

// Campus SVG viewBox: "0 0 900 620"
export const BUILDINGS: Record<string, Building> = {
  A: {
    id: "A",
    name: "Geb. A",
    fullName: "Hauptgebäude",
    x: 65,
    y: 240,
    width: 230,
    height: 155,
    color: "#e0e7ff",
    borderColor: "#6366f1",
    textColor: "#3730a3",
    floors: 3,
    description: "Verwaltung & Hörsäle",
  },
  B: {
    id: "B",
    name: "Geb. B",
    fullName: "Informatik & Mathematik",
    x: 380,
    y: 230,
    width: 210,
    height: 160,
    color: "#dbeafe",
    borderColor: "#3b82f6",
    textColor: "#1d4ed8",
    floors: 3,
    description: "PC-Pools & Labore",
  },
  C: {
    id: "C",
    name: "Geb. C",
    fullName: "Universitätsbibliothek",
    x: 100,
    y: 65,
    width: 155,
    height: 120,
    color: "#dcfce7",
    borderColor: "#22c55e",
    textColor: "#15803d",
    floors: 2,
    description: "Ausleihe & Lesesäle",
  },
  D: {
    id: "D",
    name: "Geb. D",
    fullName: "Mensa & Cafeteria",
    x: 65,
    y: 475,
    width: 185,
    height: 105,
    color: "#ffedd5",
    borderColor: "#f97316",
    textColor: "#c2410c",
    floors: 1,
    description: "Gastronomie",
  },
  E: {
    id: "E",
    name: "Geb. E",
    fullName: "Chemie & Physik",
    x: 650,
    y: 235,
    width: 190,
    height: 150,
    color: "#fdf4ff",
    borderColor: "#a855f7",
    textColor: "#7e22ce",
    floors: 3,
    description: "Labore & Forschung",
  },
};

export const ROOMS: Record<string, Room> = {
  // Building A - Floor 0
  A001: { id: "A001", buildingId: "A", floor: 0, name: "Infobüro", position: 0, side: "S" },
  A002: { id: "A002", buildingId: "A", floor: 0, name: "Sekretariat", position: 0, side: "N" },
  A003: { id: "A003", buildingId: "A", floor: 0, name: "Prüfungsamt", position: 1, side: "N" },
  A004: { id: "A004", buildingId: "A", floor: 0, name: "Studentensekretariat", position: 1, side: "S" },
  A005: { id: "A005", buildingId: "A", floor: 0, name: "Büro Prof. Schmidt", position: 2, side: "N" },
  A006: { id: "A006", buildingId: "A", floor: 0, name: "Büro Prof. Müller", position: 2, side: "S" },
  A007: { id: "A007", buildingId: "A", floor: 0, name: "Konferenzraum", position: 3, side: "N" },
  A008: { id: "A008", buildingId: "A", floor: 0, name: "Kopierraum", position: 3, side: "S" },
  // Building A - Floor 1
  A101: { id: "A101", buildingId: "A", floor: 1, name: "Hörsaal A", position: 0, side: "N" },
  A102: { id: "A102", buildingId: "A", floor: 1, name: "Hörsaal B", position: 0, side: "S" },
  A103: { id: "A103", buildingId: "A", floor: 1, name: "Seminarraum 1", position: 1, side: "N" },
  A104: { id: "A104", buildingId: "A", floor: 1, name: "Seminarraum 2", position: 1, side: "S" },
  A105: { id: "A105", buildingId: "A", floor: 1, name: "Seminarraum 3", position: 2, side: "N" },
  A106: { id: "A106", buildingId: "A", floor: 1, name: "Seminarraum 4", position: 2, side: "S" },
  A107: { id: "A107", buildingId: "A", floor: 1, name: "Projektionslabor", position: 3, side: "N" },
  A108: { id: "A108", buildingId: "A", floor: 1, name: "Übungsraum", position: 3, side: "S" },
  // Building A - Floor 2
  A201: { id: "A201", buildingId: "A", floor: 2, name: "Forschungslabor", position: 0, side: "N" },
  A202: { id: "A202", buildingId: "A", floor: 2, name: "Büro Lehrstuhl A", position: 0, side: "S" },
  A203: { id: "A203", buildingId: "A", floor: 2, name: "Büro Lehrstuhl B", position: 1, side: "N" },
  A204: { id: "A204", buildingId: "A", floor: 2, name: "Büro Lehrstuhl C", position: 1, side: "S" },
  A205: { id: "A205", buildingId: "A", floor: 2, name: "Besprechungsraum", position: 2, side: "N" },
  A206: { id: "A206", buildingId: "A", floor: 2, name: "Archiv", position: 2, side: "S" },
  A207: { id: "A207", buildingId: "A", floor: 2, name: "Serverraum", position: 3, side: "N" },
  A208: { id: "A208", buildingId: "A", floor: 2, name: "Technikraum", position: 3, side: "S" },

  // Building B - Floor 0
  B001: { id: "B001", buildingId: "B", floor: 0, name: "PC-Pool 1", position: 0, side: "S" },
  B002: { id: "B002", buildingId: "B", floor: 0, name: "PC-Pool 2", position: 0, side: "N" },
  B003: { id: "B003", buildingId: "B", floor: 0, name: "PC-Pool 3", position: 1, side: "S" },
  B004: { id: "B004", buildingId: "B", floor: 0, name: "Printerpool", position: 1, side: "N" },
  B005: { id: "B005", buildingId: "B", floor: 0, name: "Linux-Labor", position: 2, side: "S" },
  B006: { id: "B006", buildingId: "B", floor: 0, name: "Robotiklabor", position: 2, side: "N" },
  B007: { id: "B007", buildingId: "B", floor: 0, name: "Lager", position: 3, side: "S" },
  B008: { id: "B008", buildingId: "B", floor: 0, name: "Serverraum", position: 3, side: "N" },
  // Building B - Floor 1
  B101: { id: "B101", buildingId: "B", floor: 1, name: "Hörsaal C", position: 0, side: "N" },
  B102: { id: "B102", buildingId: "B", floor: 1, name: "Hörsaal D", position: 0, side: "S" },
  B103: { id: "B103", buildingId: "B", floor: 1, name: "Seminarraum 5", position: 1, side: "N" },
  B104: { id: "B104", buildingId: "B", floor: 1, name: "Seminarraum 6", position: 1, side: "S" },
  B105: { id: "B105", buildingId: "B", floor: 1, name: "Übungsraum", position: 2, side: "N" },
  B106: { id: "B106", buildingId: "B", floor: 1, name: "Mathematiklabor", position: 2, side: "S" },
  B107: { id: "B107", buildingId: "B", floor: 1, name: "Projektraum", position: 3, side: "N" },
  B108: { id: "B108", buildingId: "B", floor: 1, name: "Besprechungsraum", position: 3, side: "S" },
  // Building B - Floor 2
  B201: { id: "B201", buildingId: "B", floor: 2, name: "Büro Prof. Bauer", position: 0, side: "N" },
  B202: { id: "B202", buildingId: "B", floor: 2, name: "Büro Prof. Koch", position: 0, side: "S" },
  B203: { id: "B203", buildingId: "B", floor: 2, name: "Büro Dr. Weber", position: 1, side: "N" },
  B204: { id: "B204", buildingId: "B", floor: 2, name: "Büro Dr. Hoffmann", position: 1, side: "S" },
  B205: { id: "B205", buildingId: "B", floor: 2, name: "Forschungsgruppe KI", position: 2, side: "N" },
  B206: { id: "B206", buildingId: "B", floor: 2, name: "Forschungsgruppe ML", position: 2, side: "S" },
  B207: { id: "B207", buildingId: "B", floor: 2, name: "Konferenzraum", position: 3, side: "N" },
  B208: { id: "B208", buildingId: "B", floor: 2, name: "Bibliothek Inf.", position: 3, side: "S" },

  // Building C - Floor 0
  C001: { id: "C001", buildingId: "C", floor: 0, name: "Ausleihe", position: 0, side: "S" },
  C002: { id: "C002", buildingId: "C", floor: 0, name: "Rückgabe", position: 0, side: "N" },
  C003: { id: "C003", buildingId: "C", floor: 0, name: "Lesesaal 1", position: 1, side: "S" },
  C004: { id: "C004", buildingId: "C", floor: 0, name: "Lesesaal 2", position: 1, side: "N" },
  C005: { id: "C005", buildingId: "C", floor: 0, name: "Kopierstelle", position: 2, side: "S" },
  C006: { id: "C006", buildingId: "C", floor: 0, name: "Info-Schalter", position: 2, side: "N" },
  // Building C - Floor 1
  C101: { id: "C101", buildingId: "C", floor: 1, name: "Fachbereich Technik", position: 0, side: "N" },
  C102: { id: "C102", buildingId: "C", floor: 1, name: "Fachbereich Naturwiss.", position: 0, side: "S" },
  C103: { id: "C103", buildingId: "C", floor: 1, name: "Digitale Medien", position: 1, side: "N" },
  C104: { id: "C104", buildingId: "C", floor: 1, name: "Archivlesesaal", position: 1, side: "S" },
  C105: { id: "C105", buildingId: "C", floor: 1, name: "Stille Zone", position: 2, side: "N" },
  C106: { id: "C106", buildingId: "C", floor: 1, name: "Gruppenarbeitsraum", position: 2, side: "S" },

  // Building D - Floor 0
  D001: { id: "D001", buildingId: "D", floor: 0, name: "Mensasaal", position: 0, side: "N" },
  D002: { id: "D002", buildingId: "D", floor: 0, name: "Cafeteria", position: 0, side: "S" },
  D003: { id: "D003", buildingId: "D", floor: 0, name: "Kasse", position: 1, side: "N" },
  D004: { id: "D004", buildingId: "D", floor: 0, name: "Essensausgabe", position: 1, side: "S" },

  // Building E - Floor 0
  E001: { id: "E001", buildingId: "E", floor: 0, name: "Chemielabor 1", position: 0, side: "S" },
  E002: { id: "E002", buildingId: "E", floor: 0, name: "Chemielabor 2", position: 0, side: "N" },
  E003: { id: "E003", buildingId: "E", floor: 0, name: "Analyselabor", position: 1, side: "S" },
  E004: { id: "E004", buildingId: "E", floor: 0, name: "Syntheselabor", position: 1, side: "N" },
  E005: { id: "E005", buildingId: "E", floor: 0, name: "Physiklabor 1", position: 2, side: "S" },
  E006: { id: "E006", buildingId: "E", floor: 0, name: "Physiklabor 2", position: 2, side: "N" },
  E007: { id: "E007", buildingId: "E", floor: 0, name: "Lagerlabor", position: 3, side: "S" },
  E008: { id: "E008", buildingId: "E", floor: 0, name: "Sicherheitslabor", position: 3, side: "N" },
  // Building E - Floor 1
  E101: { id: "E101", buildingId: "E", floor: 1, name: "Labor Organik", position: 0, side: "N" },
  E102: { id: "E102", buildingId: "E", floor: 1, name: "Labor Anorganik", position: 0, side: "S" },
  E103: { id: "E103", buildingId: "E", floor: 1, name: "Spektroskopie", position: 1, side: "N" },
  E104: { id: "E104", buildingId: "E", floor: 1, name: "Chromatographie", position: 1, side: "S" },
  E105: { id: "E105", buildingId: "E", floor: 1, name: "Physik-Hörsaal", position: 2, side: "N" },
  E106: { id: "E106", buildingId: "E", floor: 1, name: "Seminarraum", position: 2, side: "S" },
  E107: { id: "E107", buildingId: "E", floor: 1, name: "Projektraum", position: 3, side: "N" },
  E108: { id: "E108", buildingId: "E", floor: 1, name: "Lehrküche Chem.", position: 3, side: "S" },
  // Building E - Floor 2
  E201: { id: "E201", buildingId: "E", floor: 2, name: "Büro Prof. Fischer", position: 0, side: "N" },
  E202: { id: "E202", buildingId: "E", floor: 2, name: "Büro Prof. Wagner", position: 0, side: "S" },
  E203: { id: "E203", buildingId: "E", floor: 2, name: "Theoretische Physik", position: 1, side: "N" },
  E204: { id: "E204", buildingId: "E", floor: 2, name: "Quantenphysik", position: 1, side: "S" },
  E205: { id: "E205", buildingId: "E", floor: 2, name: "Nanolabor", position: 2, side: "N" },
  E206: { id: "E206", buildingId: "E", floor: 2, name: "Messlabor", position: 2, side: "S" },
  E207: { id: "E207", buildingId: "E", floor: 2, name: "Konferenzraum", position: 3, side: "N" },
  E208: { id: "E208", buildingId: "E", floor: 2, name: "Rechnerpool", position: 3, side: "S" },
};

// H1 = north horizontal walkway at y=211
// H2 = south horizontal walkway at y=455
// V_W = vertical walkway at x=295 (east of building A)
// V_E = vertical walkway at x=650 (west of building E)
// H_MID_W = short horizontal between A_E and B_W at y=315
// H_MID_E = short horizontal between B_E and E_W at y=315

export const OUTDOOR_NODES: Record<string, { x: number; y: number }> = {
  // Building entrance nodes
  C_S: { x: 177, y: 185 },
  A_N: { x: 180, y: 240 },
  A_S: { x: 180, y: 395 },
  A_E: { x: 295, y: 315 },
  B_N: { x: 485, y: 230 },
  B_S: { x: 485, y: 390 },
  B_W: { x: 380, y: 315 },
  B_E: { x: 590, y: 315 },
  D_N: { x: 157, y: 475 },
  E_N: { x: 745, y: 235 },
  E_S: { x: 745, y: 385 },
  E_W: { x: 650, y: 315 },
  // Junction nodes on H1 (y=211)
  H1_C: { x: 177, y: 211 },
  H1_A: { x: 180, y: 211 },
  J295_N: { x: 295, y: 211 },
  H1_B: { x: 485, y: 211 },
  J650_N: { x: 650, y: 211 },
  H1_E: { x: 745, y: 211 },
  // Junction nodes on H2 (y=455)
  H2_D: { x: 157, y: 455 },
  H2_A: { x: 180, y: 455 },
  J295_S: { x: 295, y: 455 },
  H2_B: { x: 485, y: 455 },
  J650_S: { x: 650, y: 455 },
  H2_E: { x: 745, y: 455 },
};

export const OUTDOOR_EDGES: [string, string][] = [
  // C entrance connection
  ["C_S", "H1_C"],
  // A entrance connections
  ["A_N", "H1_A"],
  ["A_S", "H2_A"],
  ["A_E", "J295_N"],
  ["A_E", "J295_S"],
  ["A_E", "B_W"],
  // B entrance connections
  ["B_N", "H1_B"],
  ["B_S", "H2_B"],
  ["B_E", "E_W"],
  // D entrance connection
  ["D_N", "H2_D"],
  // E entrance connections
  ["E_N", "H1_E"],
  ["E_S", "H2_E"],
  ["E_W", "J650_N"],
  ["E_W", "J650_S"],
  // H1 horizontal segments
  ["H1_C", "H1_A"],
  ["H1_A", "J295_N"],
  ["J295_N", "H1_B"],
  ["H1_B", "J650_N"],
  ["J650_N", "H1_E"],
  // H2 horizontal segments
  ["H2_D", "H2_A"],
  ["H2_A", "J295_S"],
  ["J295_S", "H2_B"],
  ["H2_B", "J650_S"],
  ["J650_S", "H2_E"],
];

// Which outdoor nodes are used to enter/exit each building
export const BUILDING_ENTRANCES: Record<string, string[]> = {
  A: ["A_N", "A_S", "A_E"],
  B: ["B_N", "B_S", "B_W"],
  C: ["C_S"],
  D: ["D_N"],
  E: ["E_N", "E_S", "E_W"],
};
